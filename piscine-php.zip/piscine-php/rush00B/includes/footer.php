</div>
<footer>
    Piscine PhP - Rush 00 - janvier 2017 - 42
</footer>
</body>
</html>
<?php mysqli_close($_MYSQL); ?>