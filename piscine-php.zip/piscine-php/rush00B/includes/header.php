<?php session_start(); ?>
<?php include "config/database.php"?>
<html>
<head>
    <title>Rush00</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="admin.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:200,400,700,900" rel="stylesheet">
</head>
<body>
<?php include "menu.php" ; ?>
<div class="content">