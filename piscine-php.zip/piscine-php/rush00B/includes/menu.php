<div id="menu-top">
    <ul id="menu-deroulant">
        <li><img src="menu.png" />
            <ul>
                <li>1</li>
                <li>2</li>
                <li>3</li>
            </ul>
        </li>
    </ul>
    <div id="menu-name"><h1><?php echo $_GET['name']; ?></h1></div>
    <?php
    if ($_SESSION["loggued_on_user"] == NULL) {
        echo "<div id = 'menu-login' class='button' ><a href = 'log.php' > Login</a ></div>";
        echo "<div id = 'menu-signin' class='button' ><a href = 'create.php' > Signin</a ></div>";
    }
    else
        echo "<div id='menu-logout'><a href='logout.php'>Logout</a></a></div>";
    ?>
    <div id="menu-cart" class="button"><a href="cart.php">Cart</a></div>
</div>