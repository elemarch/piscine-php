<?php
    $_HOST = 'localhost';
    $_USER = 'root';
    $_PASS = 'root';
    $_DATA = 'minishop';

    $_MYSQL = mysqli_connect($_HOST, $_USER, $_PASS, $_DATA);