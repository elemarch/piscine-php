<?php
header("Location: ", true, 302);
include "includes/header.php"
?>

<?php
header();
while (count($_SESSION))
    array_pop($_SESSION);
$_SESSION["loggued_on_user"] = "";
?>

<?php
include "includes/footer.php"
?>