<?php include "includes/header.php" ;

function getCategories($_MYSQL, $item) {
    $cats = explode(',', $item);
    $ret = [];
    foreach ($cats as $cat) {
        $cat = mysqli_query($_MYSQL, "SELECT name FROM categories WHERE id=" . $cat);
        $cat = mysqli_fetch_array($cat);
        $ret[] = $cat["name"];
    }
    return $ret;
}

var_dump($_POST);

?>
<nav>
    <ul>
        <li class="<?php if($_GET["page"] == "cat") {echo "active";} ?>"><a href="?page=cat" class="tab">Categories</a></li>
        <li class="<?php if($_GET["page"] == "itm") {echo "active";} ?>"><a href="?page=itm" class="tab">Products</a></li>
        <li class="<?php if($_GET["page"] == "usr") {echo "active";} ?>"><a href="?page=usr" class="tab">Users</a></li>
    </ul>
</nav>
<div class="tab-content">
    <?php if ($_GET["page"] == "cat") { ?>
        <form name="category-add" action="admin.php?page=cat" method="post">
            New category :
            <input type="text" placeholder="name" name="cat-name">
            <select title="select_parent" name="select_parent">
                <option value="no_parent">No parent</option>
                <?php
                    $categories = mysqli_query($_MYSQL, "SELECT * FROM categories");
                    while ($cat = mysqli_fetch_array($categories)) {
                        echo "<option value='" . $cat["name"] . "'>" . $cat["name"] . "</option>";
                    }
                ?>
            </select>
            <input type="submit" value="OK">
        </form>
        <hr>
        <table>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>parent</th>
                <th>actions</th>
            </tr>
            <?php
                $categories = mysqli_query($_MYSQL, "SELECT * FROM categories");
                while ($cat = mysqli_fetch_array($categories)) {
                    echo "<tr>" ;
                    echo "<td>" . $cat["id"] . "</td>";
                    echo "<td>" . $cat["name"] . "</td>";
                    $parent = "";
                    if ($parent = mysqli_query($_MYSQL, "SELECT id,name FROM categories WHERE id=" . $cat["parent"])) {
                        $parent = mysqli_fetch_array($parent);
                        echo "<td> (" . $parent["id"] . ")" . $parent["name"] . "</td>";
                    }
                    else { echo "<td></td>"; }
                    echo "<td>  <a class='btn btn-del' href='delete.php?cat=" . $cat["id"] . "'>delete</a>
                                <a class='btn btn-act' href='edit.php?cat=" . $cat["id"] . "'>edit</a></td>";
                    echo "</tr>" ;
                }
            ?>
        </table>
    <?php } else if ($_GET["page"] == "itm") { ?>
        <form name="item-add" action="admin.php?page=itm" method="post">
            New item :
            <input type="text">
            Price : <input type="number" placeholder="10">€<br>
            Image url : <input type="text" placeholder="www..."><br>
            Categories :
                <?php
                $categories = mysqli_query($_MYSQL, "SELECT * FROM categories");
                while ($cat = mysqli_fetch_array($categories)) {
                    echo "<input type='checkbox' name='" . $cat["name"] . "' value='" . $cat["id"] . "'>" . $cat["name"] . "</option>";
                }
                ?>
            <br><textarea placeholder="Description"></textarea>
            <br><input type="submit" value="OK">
        </form>
        <hr>
        <table>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>price</th>
                <th>picture</th>
                <th>categories</th>
                <th>description</th>
                <th>actions</th>
            </tr>
        <?php
            $items = mysqli_query($_MYSQL, "SELECT * FROM items");
            while ($itm = mysqli_fetch_array($items)) {
                echo "<tr>" ;
                echo "<td>" . $itm["id"] . "</td>" ;
                echo "<td>" . $itm["name"] . "</td>" ;
                echo "<td>" . $itm["price"] . "€</td>" ;
                echo "<td><img src='" . $itm["picture"] . "' height='20px'></td>" ;
                $categories = implode(', ', getCategories($_MYSQL, $itm["categories"]));
                echo "<td>" . $categories . "</td>" ;
                echo "<td>" . $itm["description"] . "</td>" ;
                echo "<td>  <a class='btn btn-del' href='delete.php?itm=" . $itm["id"] . "'>delete</a>
                            <a class='btn btn-act' href='edit.php?itm=" . $itm["id"] . "'>edit</a></td>";
                echo "</tr>" ;
            }
        ?>
        </table>
    <?php } else if ($_GET["page"] == "usr"){ ?>
        <form name="user-add" action="admin.php?page=usr" method="post">
        New user :
        <input type="text" placeholder="name" title="">
        <input type="password">
        <input type="submit" value="OK">
        </form>
        <hr>
        <table>
            <tr>
                <th>id</th>
                <th>name</th>
                <th>action</th>
            </tr>
            <?php
            $users = mysqli_query($_MYSQL, "SELECT * FROM users");
            while ($usr = mysqli_fetch_array($users)) {
                echo "<tr>" ;
                echo "<td>" . $usr["id"] . "</td>";
                echo "<td>" . $usr["username"] . "</td>";
                echo "<td>  <a class='btn btn-del' href='delete.php?cat=" . $usr["id"] . "'>delete</a>
                                <a class='btn btn-act' href='edit.php?cat=" . $usr["id"] . "'>edit</a></td>";
                echo "</tr>" ;
            }
            ?>
        </table>
    <?php } ?>
</div>
<?php include "includes/footer.php" ; ?>