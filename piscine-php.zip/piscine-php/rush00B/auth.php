<?php
include "includes/header.php"
?>

<?php
function auth($login, $passwd)
{
    $key = hash('whirlpool', $passwd);
    $key = hash('whirlpool', $key);

    $query = "SELECT * FROM user";
    $result = mysqli_query($_MYSQL, $query);

    while (($user = mysqli_fetch_array($result)) != NULL) {
        if ($user['username'] == $login && $user['mdp'] == $passwd)
            return true;
    }
    return false;
}
?>

<?php
include "includes/footer.php"
?>