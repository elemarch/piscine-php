<?php
include("includes/header.php");
?>

<?php
header("Location: index.php", true, 302);

$submit = $_POST["submit"];
if ($submit === "OK" && $_POST["login"] != NULL && $_POST["passwd"] != NULL && strlen($_POST['login']) < 20)
{
    $key = hash('whirlpool', $_POST["passwd"]);
    $key = hash('sha256', $key);

    $query = "SELECT * FROM user";
    $result = mysqli_query($_MYSQL, $query);

    $verif = true;
    $tab = array("login" => $_POST["login"], "passwd" => $key);
    while (($user = mysqli_fetch_array($result)) != NULL) {
        if ($user['username'] == $tab['login'])
            $verif = false;
    }

    if ($verif == true)
    {
        $query = "INSERT INTO users (username, mdp) VALUES (" . $tab['login'].", " . $tab['passwd'] . ")";
        echo "OK\n";
    }
    else
        echo "ERROR\n";
}
else
    echo "ERROR\n";
?>

<?php
include("includes/footer.php");
?>