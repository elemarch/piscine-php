<?php

include "includes/header.php" ;
?>

<br><br><br><br><br><br><br>
slkfdjfdkfdker;kfh;8oqewidfkjlv

<?php

    $query = "SELECT * FROM items WHERE id=1" ;
    $result = mysqli_query($_MYSQL, $query);
    $row = mysqli_fetch_array($result);
    var_dump($row);
    echo $row["price"];
echo "<h1>" . $row["name"] . "</h1>";

?>

patate<br>
<h1>[OBJ NAME]</h1>


<?php include "includes/footer.php" ; ?>
