#!/usr/bin/php
<?PHP
	$s = $argv[1];
	$s = preg_replace("#[\t ]+#", " ", $s);
	$s = preg_replace("#^ | $#", "", $s);
	print("$s\n");
?>