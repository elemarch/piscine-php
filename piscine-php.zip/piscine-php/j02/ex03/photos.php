#!/usr/bin/php
<?php
$url = trim($argv[1]);
// create curl resource
$curl = curl_init();

// set url
curl_setopt($curl, CURLOPT_URL, $url);

//return the transfer as a string
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

// $output contains the output string
$page = curl_exec($curl);

$url = preg_replace("#http://#", "", $url);
mkdir($url);

$imgs= [];

preg_match("#(?<=<img src=\")(.*)(?=\" )#i", $page, $imgs);

foreach ($imgs)
{
    $image = curl_init();
    
}

// close curl resource to free up system resources
curl_close($curl);

?>