#!/usr/bin/php
<?php
	function set_maj($line) {
		$a = preg_split('/(<[^>]*[^\/]>)/i', $line, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
		$l = 0;
		for ($i=1; $a[$i] ; $i++) { 
			if (preg_match("#<a.*>#", $a[$i]))
				$l = 1;			if (preg_match("#</a>#", $a[$i]))
				$l = 0;
			if ($l == 1 && !preg_match("#<.*#", $a[$i]))
				$a[$i] = strtoupper($a[$i]);
				$a[$i] = preg_replace_callback('#title="(.*)"#', function($match) {return ("title=\"" . strtoupper($match[1]) . '"');}, $a[$i]);
		}
		$line = (implode("", $a));
		return ($line);
	}

	if (!isset($argv[1]))
		return ;
	if (!($fd = fopen($argv[1], 'r')))
		return ;
	while ($line = fgets($fd))
		$a[] = set_maj($line);
	fclose($fd);
	$i = 0;
	while ($a[$i]) {
		fwrite(STDOUT, $a[$i]);
		$i += 1;
	}
?>