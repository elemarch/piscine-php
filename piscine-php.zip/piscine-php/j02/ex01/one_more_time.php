#!/usr/bin/php
<?PHP
	$s = trim($argv[1]);
	if (!isset($argv[1]))
	    return ;
	if (preg_match("#([lL]undi|[mM]ardi|[Mm]ercredi|[jJ]eudi|[vV]endredi|[sS]amedi|[dD]imanche) +[123][1-9] +([jJ]anvier|[fF]evrier|[mM]ars|[aA]vril|[mM]ai|[jJ]uin|[jJ]uillet|[aA]out|[sS]eptembre|[oO]ctobre|[nN]ovembre|[dD]ecembre) +[0-9]{4} +[0-2]?[0-9]:[0-5]?[0-9]:[0-5]?[0-9]#", $s)){
		$s = preg_replace("#\s+|:#", " ", $s);
		$date = explode(' ', $s);
		switch ($date[2]) {
			case 'janvier' || 'Janvier':
				$month = 1;
				break;
			case 'fevrier' || 'Fevrier':
				$month = 2;
				break;
			case 'mars' || 'Mars':
				$month = 3;
				break;
			case 'avril' || 'Avril':
				$month = 4;
				break;
			case 'mai' || 'Mai':
				$month = 5;
				break;
			case 'juin' || 'Juin':
				$month = 6;
				break;
			case 'juillet' || 'Juillet':
				$month = 7;
				break;
			case 'aout' || 'Aout':
				$month = 8;
				break;
			case 'septembre' || 'Septembre':
				$month = 9;
				break;
			case 'octobre' || 'Octobre':
				$month = 10;
				break;
			case 'novembre' || 'Novembre':
				$month = 11;
				break;
			case 'decembre' || 'Decembre':
				$month = 12;
				break;
		}
		date_default_timezone_set("Europe/Paris");
		print(mktime($date[4], $date[5], $date[6], $month, $date[1], $date[3]));
	}
	else
		print("Wrong Format");
	print("\n");
?>