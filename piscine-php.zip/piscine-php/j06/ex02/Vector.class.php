<?php

require_once 'Color.class.php';
require_once 'Vertex.class.php';

class Vector {
//VARIABLES: static
	static $verbose = False;

//VARIABLES: private
	private $_x = 0;
	private $_y = 0;
	private $_z = 0;
	private $_w = 0;

//METHODS: basics
	function __construct( array $a ) {
		if (!$a['orig'])
			$a['orig'] = new Vertex( array('x' => 0, 'y' => 0, 'z' => 0) );
		$this->_x = $a['dest']->getX() - $a['orig']->getX();
		$this->_y = $a['dest']->getY() - $a['orig']->getY();
		$this->_z = $a['dest']->getZ() - $a['orig']->getZ();		
		if (self::$verbose)
			print ($this . ' constructed' . PHP_EOL);
	}
	function __destruct() {		
		if (self::$verbose)
			print ($this . ' destructed' . PHP_EOL);}

	static function doc() {	print (file_get_contents('Vector.doc.txt') . PHP_EOL); }

//METHOD: getter
	function getX() { return $this->_x; }
	function getY() { return $this->_y; }
	function getZ() { return $this->_z; }
	function getW() { return $this->_w; }

//METHODS: magic
	function __toString() {
		$str = 'Vector( x:' . number_format($this->_x, 2, '.', '');
		$str .= ', y:' . number_format($this->_y, 2, '.', '');
		$str .= ', z:' . number_format($this->_z, 2, '.', '');
		$str .= ', w:' . number_format($this->_w, 2, '.', '') . ' )';
		return $str;
	}

//METHODS: maths
	function magnitude() {
		$x2 = $this->_x * $this->_x;
		$y2 = $this->_y * $this->_y;
		$z2 = $this->_z * $this->_z;
		return ( sqrt( $x2 + $y2 + $z2 ) );
	}

	function normalize() {
		if (($vlen = $this->magnitude()) == 1)
			return (clone $this);
		$vert = new Vertex( array('x' => $this->_x / $vlen, 
								  'y' => $this->_y / $vlen,
								  'z' => $this->_z / $vlen) );
		return ( new Vector( array('dest' => $vert) ) );
	}

	function add( $rhs ) {
		$vert = new Vertex( array('x' => $this->_x + $rhs->getX(),
								  'y' => $this->_y + $rhs->getY(),
								  'z' => $this->_z + $rhs->getZ()) );
		return ( new Vector( array('dest' => $vert) ) );
	}

	function sub( $rhs ) {
		$vert = new Vertex( array('x' => $this->_x - $rhs->getX(),
								  'y' => $this->_y - $rhs->getY(),
								  'z' => $this->_z - $rhs->getZ()) );
		return ( new Vector( array('dest' => $vert) ) );
	}

	function opposite() {
		$vert = new Vertex( array('x' => - $this->_x,
								  'y' => - $this->_y,
								  'z' => - $this->_z) );
		return ( new Vector( array('dest' => $vert) ) );
	}

	function scalarProduct( $k ) {
		$vert = new Vertex( array('x' => $this->_x * $k,
								  'y' => $this->_y * $k,
								  'z' => $this->_z * $k) );
		return ( new Vector( array('dest' => $vert) ) );
	}

	function dotProduct( $rhs ) { return ( $this->_x * $rhs->getX() + $this->_y * $rhs->getY() + $this->_z * $rhs->getZ() ); }

	function crossProduct( $rhs ) {
		$vert = new Vertex( array('x' => ($this->_y * $rhs->getZ()) - ($this->_z * $rhs->getY()),
								  'y' => ($this->_z * $rhs->getX()) - ($this->_x * $rhs->getZ()),
								  'z' => ($this->_x * $rhs->getY()) - ($this->_y * $rhs->getX()) ));
		return ( new Vector( array('dest' => $vert) ) );
	}

	function cos( $rhs ) { return ( $this->dotProduct($rhs) / ($this->magnitude() * $rhs->magnitude()) ); }
}

?>