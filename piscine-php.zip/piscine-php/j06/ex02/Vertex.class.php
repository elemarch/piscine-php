<?php

require_once 'Color.class.php';

class Vertex {
//VARIABLES: static
	static $verbose = False;

//VARIABLES: private
	private $_x = 0;
	private $_y = 0;
	private $_z = 0;
	private $_w = 1.0;
	private $_c = 0;

//METHODS: basics
	function __construct( array $a ) {
		if (isset($a['color']))
			$this->_c = $a['color'];
		else
			$this->_c = new Color( array('red' => 255, 'green' => 255, 'blue' => 255) );
		if (array_key_exists("w", $a))
			$this->_w = floatval($a['w']);
		else
			$this->w = 1.0;
		$this->_x = floatval($a['x']);
		$this->_y = floatval($a['y']);
		$this->_z = floatval($a['z']);
		if (Vertex::$verbose)
			print($this . 'constructed' . PHP_EOL);
	}
	function __destruct() {
		if (Vertex::$verbose)
			print($this . 'destructed' . PHP_EOL);
	}

	static function doc() {	print (file_get_contents('Vertex.doc.txt') . PHP_EOL); }

//METHODS: access get
	public function getX() { return $this->_x; }
	public function getY() { return $this->_y; }
	public function getZ() { return $this->_z; }
	public function getW() { return $this->_w; }
	public function getC() { return clone($this->_c); }

//METHODS: access set
	public function setX( $x ) { $this->_x = $x; }
	public function setY( $y ) { $this->_y = $y; }
	public function setZ( $z ) { $this->_z = $z; }
	public function setW( $w ) { $this->_z = $w; }
	public function setC( $c ) { $this->_c = $c; }

//METHODS: magic
	function __toString() {
		//format: Vertex( x: 0.00, y: 0.00, z:1.00, w:1.00, [Color( red:   0, green:   0, blue: 255 )] )
		$str = 'Vertex( x: ' . number_format($this->_x, 2);
		$str .= ', y: ' . number_format($this->_y, 2);
		$str .= ', z:' . number_format($this->_z, 2);
		$str .= ', w:' . number_format($this->_w, 2);
		if (Vertex::$verbose)
			$str .= ', ' . $this->_c;
		$str .= ') ';
		return $str;
	}

}

?>