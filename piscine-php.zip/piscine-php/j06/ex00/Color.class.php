<?php

class Color {
	public $red = 0;
	public $green = 0;
	public $blue = 0;
	static $verbose = False;

	function __construct( array $a ) {
		if (!(isset($a['red']) && isset($a['green']) && isset($a['blue']))) {
			$a = array('red' => 0xFF & ($a['rgb'] >> 0x10), 
				'green' => 0xFF & ($a['rgb'] >> 0x8), 
				'blue' => 0xFF & ($a['rgb']));
		}
		$this->red = round($a['red']);
		$this->green = round($a['green']);
		$this->blue = round($a['blue']);
		if (Color::$verbose){ print($this . 'constructed.' . PHP_EOL);	}
		return;
	}

	function __destruct() {
		if (Color::$verbose){ print($this . 'destructed.' . PHP_EOL);	}
		return;
	}

	function __toString() {
		//format: Color( red: 255, green:   0, blue:   0 ) 
		$str = 'Color( red: ';
		$str .= str_pad($this->red, "3", " ", STR_PAD_LEFT);
		$str .= ', green: ';
		$str .= str_pad($this->green, "3", " ", STR_PAD_LEFT);
		$str .= ', blue: ';
		$str .= str_pad($this->blue, "3", " ", STR_PAD_LEFT);
		$str .= ' ) ';
		return $str;
	}

	static function doc() {
		print (file_get_contents('Color.doc.txt') . PHP_EOL);
	}

	function add( $inst ) {
		$new_color = new Color( array('red' => $this->red + $inst->red, 
									'green' => $this->green + $inst->green,
									'blue' => $this->blue + $inst->blue ));
		return ($new_color);
	}

	function sub( $inst ) {
		$new_color = new Color( array('red' => $this->red - $inst->red, 
									'green' => $this->green - $inst->green,
									'blue' => $this->blue - $inst->blue ));
		return ($new_color);
	}

	function mult( $inst ) {
		$new_color = new Color( array('red' => $this->red * $inst, 
									'green' => $this->green * $inst,
									'blue' => $this->blue * $inst ));
		return ($new_color);
	}
}

?>