<?php

class Tyrion extends Lannister {
}

?>