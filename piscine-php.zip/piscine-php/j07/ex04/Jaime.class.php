<?php

class Jaime extends Lannister {
}

?>