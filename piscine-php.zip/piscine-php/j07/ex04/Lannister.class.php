<?php

class Lannister {
	function sleepWith($t) {
		if (get_class($t) == "Tyrion" OR get_class($t) == "Jaime")
			print "Not even if I'm drunk !" . PHP_EOL;
		else if (get_class($t) == "Sansa")
			print "Let's do this." . PHP_EOL;
		else if (get_class($t) == "Cersei") {
			if (get_class($this) == "Jaime")
				print "With pleasure, but only in a tower in Winterfell, then." . PHP_EOL;
			else
				print "Not even if I'm drunk !" . PHP_EOL;
		}
	}
}

?>