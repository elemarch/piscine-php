<?php

class NightsWatch {
    private $recruits = array();

    function recruit($p) {
        $this->recruits[] = $p;
    }

    function fight () {
        foreach ($this->recruits as $recruit) {
            if ($recruit instanceof IFighter)
                $recruit->fight();
        }
    }
}