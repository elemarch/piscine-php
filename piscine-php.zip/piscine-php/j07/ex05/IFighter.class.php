<?php

interface IFighter{

}