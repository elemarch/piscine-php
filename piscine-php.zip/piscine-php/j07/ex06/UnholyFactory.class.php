<?php

class UnholyFactory
{
    private $absorbed = [];

    function absorb($fighter) {
        if (is_subclass_of($fighter, "Fighter")) {
            if (in_array($fighter, $this->absorbed))
                print ("(Factory already absorbed a fighter of type $fighter->type)" . PHP_EOL);
            else {
                print ("(Factory absorbed a fighter of type $fighter->type)" . PHP_EOL);
                $this->absorbed[$fighter->type] = $fighter;
            }
        }
        else {
            print "(Factory can't absorb this, it's not a fighter)" . PHP_EOL;
        }
    }

    function fabricate ($fighter) {
        if (isset($this->absorbed[$fighter])) {
            print "(Factory fabricates a fighter of type $fighter)" . PHP_EOL;
            return $this->absorbed[$fighter];
        }
        else
            print "(Factory hasn't absorbed any fighter of type $fighter)" . PHP_EOL;
        return NULL;
    }
}