<?php

class Fighter{
    public $type;

    function __construct($t){
        $this->type = $t;
    }

}