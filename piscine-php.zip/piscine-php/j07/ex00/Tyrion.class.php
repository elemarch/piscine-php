<?php

class Tyrion extends Lannister {
	public function getSize() {
		return "My name is Tyrion" . PHP_EOL . "Short";
	}
}

?>