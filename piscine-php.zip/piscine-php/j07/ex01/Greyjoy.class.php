<?php

class Greyjoy {
	protected $familyMotto = "We do not sow";
}

?>