SELECT DATEDIFF(max(date), min(date)) AS  uptime
FROM   historique_membre
;