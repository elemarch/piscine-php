SELECT round(sum(nbr_siege) / count(nbr_siege)) AS moyenne
FROM salle
;