SELECT 
	count(*) AS nb_abo, 
	round(sum(prix)/count(*)) AS moy_abo, 
	sum(duree_abo) % 42 AS ft
FROM abonnement
;