SELECT UPPER(p.nom) as NOM, p.prenom, a.prix
FROM fiche_personne p JOIN membre m JOIN abonnement a
WHERE p.id_perso = m.id_fiche_perso AND m.id_abo = a.id_abo AND a.prix > 42
ORDER BY nom, prenom
;