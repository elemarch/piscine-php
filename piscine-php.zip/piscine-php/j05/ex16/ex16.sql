SELECT count(*) AS film
FROM historique_membre
WHERE date BETWEEN '30/10/2006' AND '30/10/2006' OR DATE_FORMAT(date, '%Y-%m-%d') LIKE "%12-24"
;