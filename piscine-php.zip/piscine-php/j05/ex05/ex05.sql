DELETE FROM ft_table
WHERE id <= 5;