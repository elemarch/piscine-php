SELECT reverse(substring(telephone, 2)) AS enohpelet
FROM distrib
WHERE telephone LIKE '05%'
;