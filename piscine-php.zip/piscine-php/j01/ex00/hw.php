#!/usr/bin/php
<?php
	print("Hello World\n");
?>