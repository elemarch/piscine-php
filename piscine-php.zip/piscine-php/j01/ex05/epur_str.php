#!/usr/bin/php
<?PHP
	function ft_split($s) {
		$s = trim($s);
		while ($p = strpos($s, ' ')) {
			$n = substr($s, 0, $p);
			$a[] = $n;
			$s = substr($s, $p);
			$s = trim($s);
		}
		$a[] = $s;
		return $a;
	}
	$a = ft_split($argv[1]);
	if ($a[0]){
		$size = count($a);
		$c = 1;
		$s = $a[0];
		while ($c < $size)
		{
			$s = $s . " " . $a[$c];
			$c += 1;
		}
		print($s);
	}
	print("\n");
?>