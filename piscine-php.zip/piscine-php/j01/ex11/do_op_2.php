#!/usr/bin/php
<?PHP
	function check_str($str) {
		return((preg_match("#[0-9]+ *[\+\-\*\/\%] *[0-9]+#", $str)));
	}
	if (count($argv) != 2) {
		print("Invalid Parameters\n");
		return;
	}
	if (!check_str(trim($argv[1]))) {
		print("Syntax Error\n");
		return;
	}
	$a = preg_split("# *([\+\-\*\/\%]) *#", $argv[1], -1, PREG_SPLIT_DELIM_CAPTURE);
	switch ($a[1]) {
		case '+':
			print($a[0] + $a[2]);
			break;
		case '-':
			print($a[0] - $a[2]);
			break;
		case '*':
			print($a[0] * $a[2]);
			break;
		case '/':
			print($a[0] / $a[2]);
			break;
		case '%':
			print($a[0] % $a[2]);
			break;
		default:
			return;
	}
	print("\n");
?>