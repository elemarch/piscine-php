#!/usr/bin/php
<?PHP
	$c = 1;
	while ($argv[$c]) {
		print("$argv[$c]\n");
		$c += 1;
	}
?>