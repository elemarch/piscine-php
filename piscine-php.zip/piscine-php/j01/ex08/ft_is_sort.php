<?PHP
	function ft_is_sort($tab) {
		$cpy = $tab;
		sort($tab);
		$c = 0;
		while ($tab[$c]) {
			if ($tab[$c] != $cpy[$c])
				return 0;
			$c += 1;
		}
		return 1;
	}
?>