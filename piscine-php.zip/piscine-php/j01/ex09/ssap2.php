#!/usr/bin/php
<?PHP
	function ft_split($s) {
		$s = trim($s);
		while ($p = strpos($s, ' ')) {
			$n = substr($s, 0, $p);
			$a[] = $n;
			$s = substr($s, $p);
			$s = trim($s);
		}
		$a[] = $s;
		return $a;
	}


	function my_sort($s1, $s2) {
		while ($s1[$i] == $s2[$i] && $s1[$i])
			$i++;
		if ($s1[$i] == $s2[$i])
			return (0);
		if (!(ctype_alnum($s1[$i]) || ctype_alnum($s2[$i])))
			return (strcmp($s1[$i], $s2[$i]));
		if (ctype_alnum($s1[$i]) && !(ctype_alnum($s2[$i])))
			return (-1);
		if (ctype_alnum($s2[$i]) && !(ctype_alnum($s1[$i])))
			return (1);
		if (ctype_alpha($s1[$i]) && !(ctype_alpha($s2[$i])))
			return (-1);
		if (ctype_alpha($s2[$i]) && !(ctype_alpha($s1[$i])))
			return (1);
		if (ctype_alpha($s1[$i]) && ctype_alpha($s2[$i]))
		{
			$tmp1 = strtolower($s1);
			$tmp2 = strtolower($s2);
			if ($tmp1[$i] != $tmp2[$i])
				return (strcmp($tmp1[$i], $tmp2[$i]));
		}
		return (strcmp($s1[$i], $s2[$i]));
	}

	$c = 1;
	while ($argv[$c]) {
		$a = ft_split($argv[$c]);
		$i = 0;
		while ($a[$i]) {
			$b[] = $a[$i];
			$i += 1;
		}
		$c += 1;
	}
	uasort($b, 'my_sort');
	$b = array_values($b);
	$c = 0;
	while ($b[$c]) {
		print("$b[$c]\n");
		$c += 1;
	}
?>