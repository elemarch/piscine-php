#!/usr/bin/php
<?PHP
	function ft_split($s) {
		$s = trim($s);
		while ($p = strpos($s, ' ')) {
			$n = substr($s, 0, $p);
			$a[] = $n;
			$s = substr($s, $p);
			$s = trim($s);
		}
		$a[] = $s;
		return $a;
	}

	$c = 1;
	while ($argv[$c]) {
		$a = ft_split($argv[$c]);
		$i = 0;
		while ($a[$i]) {
			$b[] = $a[$i];
			$i += 1;
		}
		$c += 1;
	}
	if ($b) {
		sort($b);
		$c = 0;
		while ($b[$c]) {
			print("$b[$c]\n");
			$c += 1;
		}
	}
?>