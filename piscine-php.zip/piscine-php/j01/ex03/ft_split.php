<?php
	function ft_split($s) {
		$s = trim($s);
		while ($p = strpos($s, ' ')) {
			$n = substr($s, 0, $p);
			$a[] = $n;
			$s = substr($s, $p);
			$s = trim($s);
		}
		$a[] = $s;
		sort($a);
		return $a;
	}
?>