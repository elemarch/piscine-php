#!/usr/bin/php
<?PHP
	//stocker la cle
	$key = $argv[1];
	//rechercher cle:valeur 
	for ($i=2; $argv[$i] ; $i++) { 
		if (preg_match("#$key:\w+#", $argv[$i])) {
			//stocker valeur
			$val[] = explode(":", $argv[$i]);
		}
	}
	$i = 0;
	while ($val[$i])
		$i++;
	if ($i) {
		print($val[$i - 1][1]);
		print("\n");
	}
?>