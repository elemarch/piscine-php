#!/usr/bin/php
<?php
	$c = 0;
	while ($c < 1000){
		print("X");
		$c += 1;
	}
	print("\n");
?>