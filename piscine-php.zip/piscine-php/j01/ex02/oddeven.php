#!/usr/bin/php
<?php
	$w = 0;
	print("Entrez un nombre: ");
	while ($n = fgets(STDIN)){
		$l = 0;
		$n = trim($n);
		while (isset($n[$l])){
			if ($n[$l] < '0' || $n[$l] > '9'){
				$w = 1;
				break;
			print("$l\n");
			}
			$l += 1;
		}
		if ($w || ord($n) == 0)
			print("'$n' n'est pas un chiffre\n");
		else {
			$n = intval($n);
			print("Le chiffre $n est ");
			if ($n % 2 == 1)
				print("Impair\n");
			else
				print("Pair\n");
		}
		$w = 0;
		print("Entrez un nombre: ");
	}
	print("\n");
?>