#!/usr/bin/php
<?PHP
	if (count($argv) != 4) {
		print("Incorrect Parameters\n");
		return;
	}
	$n1 = intval(trim($argv[1]));
	$n2 = intval(trim($argv[3]));
	$s = trim($argv[2]);
	switch ($s) {
		case '+':
			print($n1 + $n2);
			break;
		case '-':
			print($n1 - $n2);
			break;
		case '*':
			print($n1 * $n2);
			break;
		case '/':
			print($n1 / $n2);
			break;
		case '%':
			print($n1 % $n2);
			break;
		default:
			return;
	}
	print("\n");
?>
